<footer class="main-footer" style="background-color: #77dd77; color: black; font-size: 13px;">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <!-- Help & Contact Us Section -->
        <div class="clearfix"></div>
        <div style="margin-top: 10px;">
          <h4 style="color: black; font-size: 16px;">Help & Contact Us</h4>
          <p style="color: black; font-size: 14px;">Connect with us on social media:</p>
          <!-- Add your social media links here -->
          <ul class="list-inline">
            <li><a href="#" style="color: black;"><i class="fa fa-facebook"></i> Facebook</a></li>
            <li><a href="#" style="color: black;"><i class="fa fa-twitter"></i> Twitter</a></li>
            <li><a href="#" style="color: black;"><i class="fa fa-instagram"></i> Instagram</a></li>
            <!-- Add more social media links as needed -->
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="pull-right hidden-xs">
          <b>All rights reserved</b>
        </div>
        <b><strong>Copyright &copy; CGL</strong></b>
      </div>
    </div>
  </div>
  <!-- /.container -->
</footer>
